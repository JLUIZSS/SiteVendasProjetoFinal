package br.com.VisionTech;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VisionTechApplication {

	public static void main(String[] args) {
		SpringApplication.run(VisionTechApplication.class, args);
	}

}
